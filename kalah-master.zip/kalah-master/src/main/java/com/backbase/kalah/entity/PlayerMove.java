package com.backbase.kalah.entity;

public class PlayerMove {

    private Pit selectedPit;
    private Player player;

    public PlayerMove(String msg) {
    }

    public Pit getSelectedPit() {
        return selectedPit;
    }

    public void setSelectedPit(Pit selectedPit) {
        this.selectedPit = selectedPit;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

}
