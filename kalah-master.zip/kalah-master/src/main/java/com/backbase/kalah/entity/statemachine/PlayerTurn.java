package com.backbase.kalah.entity.statemachine;

public class PlayerTurn implements State {

    static final String GAME_ALREADY_INITIALIZED = "Game already initialized";

    @Override
    public void initialize(GameContext context) {
        throw new IllegalStateException(GAME_ALREADY_INITIALIZED);
    }

    @Override
    public void playTurn(GameContext context) {
        reorganizeStones();
        if (!doPlayersHaveStonesOnTheirPits()) {
            determineWinner();
            context.setState(context.getStandbyState());
            return;
        }

        if (lastStoneLandsInHisOwnKalah()) {
            context.setNextTurn(context.getCurrentPlayer().getTurn());
            context.setState(context.getPlayerTurn());
            return;
        }

        if (lastStoneLandsInAnOwnEmptyPit()) {
            captureStonesInOppositePit();
            context.calculateNextTurn();
            context.setState(context.getPlayerTurn());
            return;
        }

        context.calculateNextTurn();
        context.setState(context.getPlayerTurn());
    }

    private void reorganizeStones() {
        System.out.println("Reorganizing Stones...");
    }

    private boolean doPlayersHaveStonesOnTheirPits() {
        return false;
    }

    private void determineWinner() {
        System.out.println("Determining the winner...");
    }

    private boolean lastStoneLandsInHisOwnKalah() {
        return false;
    }

    public boolean lastStoneLandsInAnOwnEmptyPit() {
        return false;
    }

    private void captureStonesInOppositePit() {
        System.out.println("Capturing Stones in Opposite Pit");
    }

}
