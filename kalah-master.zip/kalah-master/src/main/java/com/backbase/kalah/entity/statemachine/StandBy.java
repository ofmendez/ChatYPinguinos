package com.backbase.kalah.entity.statemachine;

public class StandBy implements State {

    static final String GAME_NOT_INITIALIZED = "Game not initialized";

    @Override
    public void initialize(GameContext context) {
        context.assignTurnsToPlayers();
        context.setState(context.getPlayerTurn());
    }

    @Override
    public void playTurn(GameContext context) {
        throw new IllegalStateException(GAME_NOT_INITIALIZED);
    }

}
