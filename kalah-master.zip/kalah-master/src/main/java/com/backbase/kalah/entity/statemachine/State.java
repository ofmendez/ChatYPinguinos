package com.backbase.kalah.entity.statemachine;

public interface State {

    void initialize(GameContext context);

    void playTurn(GameContext context);

}
