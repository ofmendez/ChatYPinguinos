package com.backbase.kalah.boundary.websocket;

import com.backbase.kalah.control.GameCache;
import com.backbase.kalah.entity.PlayerMove;
import com.backbase.kalah.entity.statemachine.GameContext;
import org.junit.Before;
import org.junit.Test;

import javax.websocket.Session;
import java.util.logging.Logger;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class GameRoomHandlerTest {

    private GameRoomHandler sut;

    @Before
    public void setUp() {
        sut = new GameRoomHandler();
        sut.gameCache = mock(GameCache.class);
        sut.logger = mock(Logger.class);
    }

    @Test
    public void shouldStartGameWhenTwoPlayersConnect() {
        //given
        String userid1 = "userid1";
        String userid2 = "userid2";
        String roomId = "1";

        Session session = mock(Session.class);
        when(session.getId()).thenReturn(userid2);
        when(session.getQueryString()).thenReturn(roomId);

        GameContext context = spy(GameContext.class);
        doNothing().when(context).startGame();
        context.addPlayerToGame(userid1);
        when(sut.gameCache.get(anyString())).thenReturn(context);

        //when
        sut.connect(session);

        //then
        verify(context).startGame();
    }

    @Test
    public void shouldRemoveFromCacheWhenConnectionClosed() {
        Session session = mock(Session.class);
        String roomId = "1";
        when(session.getQueryString()).thenReturn(roomId);

        sut.close(session);

        verify(sut.gameCache).remove(roomId);
    }

    @Test
    public void shouldPerformMoveWhenPlayerSendMessage() {
        //given
        String userid1 = "userid1";
        String userid2 = "userid2";
        String roomId = "1";
        Session session = mock(Session.class);
        when(session.getQueryString()).thenReturn(roomId);
        when(session.getId()).thenReturn(userid1);

        String msg = "testMessage";

        GameContext context = spy(GameContext.class);
        context.addPlayerToGame(userid1);
        context.addPlayerToGame(userid2);
        doNothing().when(context).playerMove(any(PlayerMove.class));
        when(sut.gameCache.get(anyString())).thenReturn(context);

        //when
        sut.onMessage(msg, session);

        //then
        verify(context).playerMove(any(PlayerMove.class));
    }

}
