package com.backbase.kalah.entity.statemachine;

import com.backbase.kalah.entity.PlayerMove;
import org.junit.Before;
import org.junit.Test;

import java.util.logging.Logger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.Mockito.mock;

public class StandByStateTest {

    private GameContext sut;

    @Before
    public void setUp() {
        sut = new GameContext();
        sut.setState(new StandBy());
        sut.logger = mock(Logger.class);
    }

    @Test
    public void shouldChangeToPlayerTurnStateWhenGameStarted() {
        //given
        String userId1 = "1";
        String userId2 = "2";
        sut.addPlayerToGame(userId1);
        sut.addPlayerToGame(userId2);

        //when
        sut.startGame();

        //then
        assertThat(sut.getState()).isInstanceOf(PlayerTurn.class);
    }

    @Test
    public void shouldThrowExceptionWhenPlayingOnStandByState() {
        PlayerMove playermove = new PlayerMove("");

        Throwable thrown = catchThrowable(() -> {
            sut.playerMove(playermove);
        });

        assertThat(thrown).isInstanceOf(IllegalStateException.class)
                .hasMessage(StandBy.GAME_NOT_INITIALIZED);
    }

}
