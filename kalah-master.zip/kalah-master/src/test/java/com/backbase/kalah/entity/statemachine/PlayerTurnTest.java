package com.backbase.kalah.entity.statemachine;

import com.backbase.kalah.entity.PlayerMove;
import org.junit.Before;
import org.junit.Test;

import java.util.logging.Logger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.Mockito.mock;

public class PlayerTurnTest {

    private GameContext sut;

    @Before
    public void setUp() {
        sut = new GameContext();
        sut.setState(new PlayerTurn());
        sut.logger = mock(Logger.class);
    }

    @Test
    public void shouldThrowExceptionWhenInitilizingAGameInProgress() {

        Throwable thrown = catchThrowable(sut::startGame);

        assertThat(thrown).isInstanceOf(IllegalStateException.class)
                .hasMessage(PlayerTurn.GAME_ALREADY_INITIALIZED);
    }

    @Test
    public void shouldChangeToStandbyStateWhenPlayersHaveNoMoreStonesOnPits() {
        PlayerMove playermove = new PlayerMove("");

        sut.playerMove(playermove);

        assertThat(sut.getState().equals(sut.getStandbyState()));
    }

}
