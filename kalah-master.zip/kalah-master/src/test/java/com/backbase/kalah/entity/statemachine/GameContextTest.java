package com.backbase.kalah.entity.statemachine;

import java.util.logging.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;

public class GameContextTest {

    private GameContext sut;

    @Before
    public void setUp() {
        sut = new GameContext();
        sut.logger = mock(Logger.class);
    }

    @Test
    public void shouldThrowExceptionWhenAddingAThirdPlayer() {
        sut.addPlayerToGame("one");
        sut.addPlayerToGame("two");

        Throwable thrown = catchThrowable(() -> {
            sut.addPlayerToGame("three");
        });

        assertThat(thrown).isInstanceOf(IllegalStateException.class)
                .hasMessage(GameContext.CAN_NOT_ADD_MORE_PLAYERS);
    }

}
